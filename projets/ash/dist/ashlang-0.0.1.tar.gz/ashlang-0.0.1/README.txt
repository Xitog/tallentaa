# Ash

A simple language transpiling to Python. Its default implementation is written in Python 3.

## Comments

``-- This is a comment``

## Variables

Declare and assign a variable:
``a = 5``

Declare, assign and restrict a variable to a type:
``a : int = 5``

## Types and operators

* ``int`` for integer
* ``flt`` for float
* ``bool`` for boolean
* ``"..."`` or ``'...'`` for strings
* ``[a, b]`` for list
* ``[a = 5, b = 34]`` for hash

## Functions and procedures

Todo

## Class

Todo

## Modules

Todo

## Exception

Todo

## Links

Todo

Damien Gouteux 2020