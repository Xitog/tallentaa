class ash:
    pass
